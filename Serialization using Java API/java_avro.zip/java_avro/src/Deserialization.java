import java.io.File;
import java.io.IOException;

import org.apache.avro.file.DataFileReader;
import org.apache.avro.io.DatumReader;
import org.apache.avro.specific.SpecificDatumReader;
public class Deserialization {

	public static void main(String[] args) throws Exception {
		//DeSerializing the objects
	      DatumReader<Patient_Records.Patients> patDatumReader = new SpecificDatumReader<Patient_Records.Patients>(Patient_Records.Patients.class);
			
	      //Instantiating DataFileReader
	      DataFileReader<Patient_Records.Patients> dataFileReader = new DataFileReader<Patient_Records.Patients>(new File("C://Avro_Work//java_avro/bin/patients.avro"), patDatumReader);
	      
	      Patient_Records.Patients pat=null;
			
	      while(dataFileReader.hasNext()){
	      
	         pat=dataFileReader.next(pat);
	         System.out.println(pat);}
	      dataFileReader.close();    

}
	}
