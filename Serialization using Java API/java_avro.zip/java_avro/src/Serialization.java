import java.io.File;
import java.io.IOException;



import org.apache.avro.file.DataFileWriter;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.specific.SpecificDatumWriter;

import Patient_Records.Patients;
public class Serialization {

	public static void main(String[] args) throws Exception {
		//First record of patient
		Patients pat1 = new Patients();
		pat1.setPatientID(1);
		pat1.setName("JAVAPat1");
		pat1.setPhone("9121234561");
		pat1.setEmail("javapat1@hosp.com");
		pat1.setUsername("javapat1");
		pat1.setPassword("javapat1");
		
		Patients pat2 = new Patients();
		pat2.setPatientID(2);
		pat2.setName("JAVAPat2");
		pat2.setPhone("9121234562");
		pat2.setEmail("javapat2@hosp.com");
		pat2.setUsername("javapat2");
		pat2.setPassword("javapat2");
		
		Patients pat3 = new Patients();
		pat3.setPatientID(23);
		pat3.setName("JAVAPat3");
		pat3.setPhone("9121234563");
		pat3.setEmail("javapat3@hosp.com");
		pat3.setUsername("javapat3");
		pat3.setPassword("javapat3");
		
		//Instantiate DatumWriter class
	      DatumWriter<Patient_Records.Patients> patDatumWriter = new SpecificDatumWriter<Patient_Records.Patients>(Patient_Records.Patients.class);
	      DataFileWriter<Patient_Records.Patients> patFileWriter = new DataFileWriter<Patient_Records.Patients>(patDatumWriter);
	      
	      patFileWriter.create(pat1.getSchema(),new File("C://Avro_Work//java_avro/bin/patients.avro"));
		
	     if (pat1 != null) { patFileWriter.append(pat1);}
	     if (pat2 != null) { patFileWriter.append(pat2);}
	     if (pat3 != null) { patFileWriter.append(pat3);}
		
	      if (patFileWriter!=null) {patFileWriter.close();};
		
	      System.out.println("data successfully serialized");
		
		
		
	}

}
